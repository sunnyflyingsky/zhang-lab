rna2meme  -rna /pnas/yangyg_group/zhangting/software/meme_4.12.0/motif/motif_CISBP_RNA_narrow/m6a.txt > m6a.out

beeml2meme /pnas/yangyg_group/zhangting/software/meme_4.12.0/motif/motif_CISBP_RNA_narrow/molecular-cell.txt > molecular-cell.out
