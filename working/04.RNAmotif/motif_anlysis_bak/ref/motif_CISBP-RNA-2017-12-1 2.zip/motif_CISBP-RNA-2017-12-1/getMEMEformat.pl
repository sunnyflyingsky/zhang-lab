#!/usr/bin/perl
chdir '/pnas/yangyg_group/zhangting/software/meme_4.12.0/motif/motif_CISBP-RNA-2017-12-1';
use warnings;
use strict;
open IN,"RBP.txt";
<IN>;
my %category=();
my %UTR=();

while(<IN>){
	chomp;
	my @tmp = split /\t/;
	if(exists $category{$tmp[4]}{$tmp[1]}){
		$category{$tmp[4]}{$tmp[1]}=$category{$tmp[4]}{$tmp[1]}."_$tmp[3]";	
	}else{
		$category{$tmp[4]}{$tmp[1]}="$tmp[3]";	
	}
	$UTR{$tmp[1]}=$tmp[0];
}

foreach my  $key1 ( keys %category){
	open OUT1,">$key1.meme";
	open OUT2,">$key1.dna_encoded.meme";
	print OUT1 "MEME version 4\n\nALPHABET= ACGU\n\nBackground letter frequencies (from uniform background):\nA 0.25000 C 0.25000 G 0.25000 U 0.25000\n\n";
	print OUT2 "MEME version 4\n\nALPHABET= ACGT\n\nstrands: + -\n\nBackground letter frequencies (from uniform background):\nA 0.25000 C 0.25000 G 0.25000 U 0.25000\n\n";

	foreach my $key2 (keys %{$category{$key1}}){
		open IN,"./pwms/$key2.txt";
		my @matrix = <IN>;
		chomp(@matrix);
		next if(scalar(@matrix)<=0);
		print OUT1 "MOTIF $key2 \($category{$key1}{$key2}\)\n\n";
		print OUT1 "letter-probability matrix: alength= 4 w= ".$#matrix." nsites= 20 E= 0\n";
		print OUT2 "MOTIF $key2 \($category{$key1}{$key2}\)\n\n";
		print OUT2 "letter-probability matrix: alength= 4 w= ".$#matrix." nsites= 20 E= 0\n";
		
		foreach (@matrix[1..$#matrix]){
			my @tmp = split /\t/;
			print OUT1 "  ".join("\t",@tmp[1..$#tmp])."\t\n";
			print OUT2 "  ".join("\t",@tmp[1..$#tmp])."\t\n";
		}
		print OUT1 "\n\n";
		print OUT1 "URL http://cisbp-rna.ccbr.utoronto.ca/TFreport.php?searchTF=".$UTR{$key2}."\n\n";
		print OUT2 "\n\n";
		print OUT2 "URL http://cisbp-rna.ccbr.utoronto.ca/TFreport.php?searchTF=".$UTR{$key2}."\n\n";
	 }
	

}
